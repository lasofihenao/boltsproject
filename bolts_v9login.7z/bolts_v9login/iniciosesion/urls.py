from django.urls import path
from iniciosesion import views

urlpatterns = [path("login", views.login_request), path("signup", views.signup)]
