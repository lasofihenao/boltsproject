from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages

from iniciosesion.forms import FormularioRegistrar

# Create your views here.

def login_request(request):
    mensaje = ""
    form = AuthenticationForm()
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            usuario = form.cleaned_data.get("username")
            contrasenna = form.cleaned_data.get("password")
            user = authenticate(username=usuario, password=contrasenna)
            if user is not None:
                login(request, user)  # para loguear al usuario#
                messages.info(request, f"{usuario} logueado")
                return redirect("/")
            else:
                mensaje = "Error de usuario o contraseña"
                messages.error(request, "Error de usuario o contraseña")
        else:
            mensaje = "Error de usuario o contraseña"
            messages.error(request, "Error de usuario o contraseña")
    return render(request, "login.html", {"mensaje": mensaje})


def signup(request):
    mensaje = ""
    if request.method == "POST":
        form = FormularioRegistrar(request.POST)
        print(form)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect("/auth/login")
        else:
            mensaje = "Por favor revise los datos ingresados."
    else:
        form = FormularioRegistrar()

    return render(request, "signup.html", {"form": form, "mensaje": mensaje})
