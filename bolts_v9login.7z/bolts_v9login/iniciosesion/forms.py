from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario


class FormularioRegistrar(UserCreationForm):
    rut = forms.CharField(max_length=12)

    class Meta:
        model = Usuario
        fields = ("username", "rut", "rol")
